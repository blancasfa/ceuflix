// MODELO 
const ModeloPeliculas = {
    obtenerPeliculas: function() {
        return JSON.parse(localStorage.getItem('mis_peliculas')) || [];
    },
    guardarPeliculas: function(peliculas) {
        localStorage.setItem('mis_peliculas', JSON.stringify(peliculas));
    },
    inicializarPeliculas: function() {
        let peliculas = this.obtenerPeliculas();
        if (peliculas.length === 0) {
            peliculas = [
                { titulo: "Superlópez", director: "Javier Ruiz Caldera", miniatura: "files/superlopez.png" },
                { titulo: "Jurassic Park", director: "Steven Spielberg", miniatura: "files/jurassicpark.png" },
                { titulo: "Interstellar", director: "Christopher Nolan", miniatura: "files/interstellar.png" }
            ];
            this.guardarPeliculas(peliculas);
        }
        return peliculas;
    }
};

// CONTROLADORES
const initContr = () => {
    // Inicializar las películas y mostrar la vista principal.
    ModeloPeliculas.inicializarPeliculas();
    indexContr();
};

function indexContr() {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    indexView(peliculas);
}

function editContr(i) {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    const pelicula = peliculas[i];
    editView(i, pelicula);
}

function updateContr(i) {
    const titulo = document.getElementById('editTitulo').value;
    const director = document.getElementById('editDirector').value;
    const miniatura = document.getElementById('editMiniatura').value;

    if (titulo && director && miniatura) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas[i] = { titulo, director, miniatura };
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr();
    } else {
        alert("Por favor, completa todos los campos.");
    }
}

function deleteContr(i) {
    if (confirm("¿Seguro que deseas eliminar esta película?")) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas.splice(i, 1); // Elimina la película en la posición i
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr(); // Vuelve a la vista principal
    }
}

function showContr(i) {
    const peliculas = ModeloPeliculas.obtenerPeliculas();
    const pelicula = peliculas[i];
    showView(pelicula);
}

function newContr() {
    newView();
}

function createContr() {
    const titulo = document.getElementById('newTitulo').value;
    const director = document.getElementById('newDirector').value;
    const miniatura = document.getElementById('newMiniatura').value;

    if (titulo && director && miniatura) {
        const peliculas = ModeloPeliculas.obtenerPeliculas();
        peliculas.push({ titulo, director, miniatura });
        ModeloPeliculas.guardarPeliculas(peliculas);
        indexContr();
    } else {
        alert("Por favor, completa todos los campos.");
    }
}
function resetContr() {
    // Esta función restablece las películas predeterminadas
    ModeloPeliculas.guardarPeliculas(ModeloPeliculas.inicializarPeliculas());
    alert("La colección se ha restablecido a las películas iniciales.");
    indexContr();
}

// Event Listener para mostrar la colección del usuario
document.getElementById('view-collection-button').addEventListener('click', () => {
    indexContr();
})
// VISTAS
function indexView(peliculas) {
    const moviesContainer = document.getElementById('movies-container');
    moviesContainer.innerHTML = ''; // Limpiar el contenedor para agregar nuevas tarjetas

    peliculas.forEach((pelicula, i) => {
        const movieSlide = document.createElement('div');
        movieSlide.classList.add('swiper-slide');
        movieSlide.innerHTML = `
            <div class="movie-card">
                <img src="${pelicula.miniatura}" alt="Carátula de ${pelicula.titulo}">
                <h3>${pelicula.titulo}</h3>
                <p>Director: ${pelicula.director}</p>
                <button class="show" data-my-id="${i}">Ver</button>
                <button class="edit" data-my-id="${i}">Editar</button>
                <button class="delete" data-my-id="${i}">Borrar</button>
            </div>
        `;
        moviesContainer.appendChild(movieSlide);
    });
}


function editView(i, pelicula) {
    const main = document.getElementById('main');
    main.innerHTML = `
        <h2>Editar Película</h2>
        <form>
            <label for="editTitulo">Título</label>
            <input type="text" id="editTitulo" value="${pelicula.titulo}">
            <label for="editDirector">Director</label>
            <input type="text" id="editDirector" value="${pelicula.director}">
            <label for="editMiniatura">Miniatura (URL)</label>
            <input type="text" id="editMiniatura" value="${pelicula.miniatura}">
            <button type="button" class="update" data-my-id="${i}">Actualizar</button>
            <button type="button" class="index">Volver</button>
        </form>
    `;
}

function showView(pelicula) {
    const main = document.getElementById('main');
    main.innerHTML = `
        <h2>${pelicula.titulo}</h2>
        <p>Director: ${pelicula.director}</p>
        <img src="${pelicula.miniatura}" alt="Carátula de ${pelicula.titulo}">
        <button class="index">Volver</button>
    `;
}

function newView() {
    const main = document.getElementById('main');
    main.innerHTML = `
        <h2>Crear Película</h2>
        <form>
            <label for="newTitulo">Título</label>
            <input type="text" id="newTitulo">
            <label for="newDirector">Director</label>
            <input type="text" id="newDirector">
            <label for="newMiniatura">Miniatura (URL)</label>
            <input type="text" id="newMiniatura">
            <button type="button" class="create">Crear</button>
            <button type="button" class="index">Volver</button>
        </form>
    `;
}

// ROUTER de eventos usando event delegation
document.addEventListener("click", function(event) {
    if (event.target.classList.contains("show")) {
        showContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("new")) {
        newContr();
    } else if (event.target.classList.contains("create")) {
        createContr();
    } else if (event.target.classList.contains("edit")) {
        editContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("update")) {
        updateContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("delete")) {
        deleteContr(event.target.dataset.myId);
    } else if (event.target.classList.contains("index")) {
        indexContr();
    }
});

// Inicialización
document.addEventListener('DOMContentLoaded', initContr);
// Event Listener para resetear la colección del usuario
document.getElementById('reset-collection-button').addEventListener('click', () => {
    resetContr();
});

document.addEventListener('DOMContentLoaded', function () {
    initContr();

        // Configuración para Swiper
        const swiper = new Swiper('.swiper-container', {
            slidesPerView: 3,
            spaceBetween: 30,
            loop: true,
            centeredSlides: false,  // Para evitar que se centre demasiado
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            breakpoints: {
                768: {
                    slidesPerView: 2, // Para pantallas más pequeñas
                    spaceBetween: 20,
                },
                480: {
                    slidesPerView: 1, // Para móviles
                    spaceBetween: 10,
                },
            },
        });
    });
    

