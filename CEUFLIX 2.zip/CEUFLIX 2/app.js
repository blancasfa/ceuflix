// Reemplaza con tu clave de API de TMDb
const API_KEY = '7f5a7dd038579b195e6518f6c23385d7';

// Función para buscar películas usando TMDb
function searchContr(query) {
    const url = `https://api.themoviedb.org/3/search/movie?query=${encodeURIComponent(query)}&api_key=${API_KEY}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.results && data.results.length > 0) {
                resultsView(data.results);
            } else {
                document.getElementById('search-results').innerHTML = 'No se encontraron resultados.';
            }
        })
        .catch(error => console.error('Error en la solicitud a TMDb:', error));
}

// Mostrar los resultados de la búsqueda
function resultsView(resultados) {
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = ''; // Limpiar resultados anteriores

    resultados.forEach(movie => {
        const movieElement = document.createElement('div');
        movieElement.className = 'movie-result';

        movieElement.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w200${movie.poster_path}" alt="${movie.title}">
            <h3>${movie.title}</h3>
            <p>Fecha de lanzamiento: ${movie.release_date || 'Desconocido'}</p>
            <button class="add-from-api" data-movie-id="${movie.id}">Añadir</button>
        `;

        resultsContainer.appendChild(movieElement);
    });

    // Añadir funcionalidad a los botones "Añadir"
    document.querySelectorAll('.add-from-api').forEach(button => {
        button.addEventListener('click', (event) => {
            const movieId = event.target.getAttribute('data-movie-id');
            addFromAPIContr(movieId);
            event.target.disabled = true; // Deshabilitar el botón después de añadir la película
        });
    });
}

// Añadir una película desde la API de TMDb
function addFromAPIContr(movieId) {
    const url = `https://api.themoviedb.org/3/movie/${movieId}?api_key=${API_KEY}`;

    fetch(url)
        .then(response => response.json())
        .then(movie => {
            let peliculas = ModeloPeliculas.obtenerPeliculas();

            if (!peliculas.some(m => m.titulo === movie.title)) {
                const nuevaPelicula = {
                    titulo: movie.title,
                    director: 'Desconocido',  // No siempre está disponible el director en la API.
                    miniatura: movie.poster_path ? `https://image.tmdb.org/t/p/w200${movie.poster_path}` : 'files/placeholder.png'
                };
                peliculas.push(nuevaPelicula);
                ModeloPeliculas.guardarPeliculas(peliculas);
                alert(`${movie.title} ha sido añadido a tu colección.`);
            } else {
                alert('La película ya está en tu colección.');
            }
        })
        .catch(error => console.error('Error al agregar la película:', error));
}

// Event Listener para el botón de búsqueda
document.getElementById('movie-search-button').addEventListener('click', () => {
    const query = document.getElementById('movie-search-input').value.trim();
    if (query) {
        searchContr(query);
    } else {
        alert('Por favor, ingresa un término de búsqueda.');
    }
});
